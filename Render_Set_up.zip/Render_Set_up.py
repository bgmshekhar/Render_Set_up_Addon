bl_info = {
    "name": "GCR Addon",
    "category": "Render",
    "author": "Chandra Shekhar",
    "description": "Addon for saving Blender project and generating .ipynb files.",
    "version": (1.0),
    "support": "COMMUNITY",
    "tracker_url": "https://bgmshekhar.github.io/Chanda3DArt.com/",
}


import bpy
import json

bl_info = {
    "name": "GCR Addon",
    "blender": (2, 80, 0),
    "category": "Render",
}

def get_blender_version_items():
    """ Generate version items for EnumProperty """
    versions = [
        ('3.0', '3.0', 'Blender 3.0'),
        ('3.1', '3.1', 'Blender 3.1'),
        ('3.2', '3.2', 'Blender 3.2'),
        ('3.3', '3.3', 'Blender 3.3'),
        ('3.4', '3.4', 'Blender 3.4'),
        ('3.5', '3.5', 'Blender 3.5'),
        ('3.6', '3.6', 'Blender 3.6'),
        ('4.0', '4.0', 'Blender 4.0'),
        ('4.1', '4.1', 'Blender 4.1'),
        ('4.2', '4.2', 'Blender 4.2')
    ]
    return versions

class GCRAddonPanel(bpy.types.Panel):
    bl_label = "GCR Addon"
    bl_idname = "GCR_PT_addon_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'GCR Addon'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Select Button
        layout.operator("render.save_and_show_options", text="Select")

        # Conditional display of options
        if scene.gcr_show_options:
            layout.prop(scene, "gcr_render_engine", text="Render Engine")
            layout.prop(scene, "gcr_first_frame", text="First Frame")
            layout.prop(scene, "gcr_last_frame", text="Last Frame")

            # Blender version selection
            layout.prop(scene, "gcr_blender_version", text="Blender Version")

            # Save .ipynb File button
            layout.operator("render.save_ipynb_file", text="Save .ipynb File")

class SaveAndShowOptionsOperator(bpy.types.Operator):
    bl_idname = "render.save_and_show_options"
    bl_label = "Save and Show Options"

    def execute(self, context):
        # Save the current file
        if not bpy.data.filepath:
            self.report({'ERROR'}, "Please save your .blend file first.")
            return {'CANCELLED'}
        
        bpy.ops.wm.save_mainfile()

        # Show additional options
        context.scene.gcr_show_options = True

        return {'FINISHED'}

class SavePyFileOperator(bpy.types.Operator):
    bl_idname = "render.save_ipynb_file"
    bl_label = "Save .ipynb File"

    def execute(self, context):
        # Get selected Blender version
        blender_version = context.scene.gcr_blender_version

        # Define the path and filename for the .ipynb file
        notebook_name = "my_notebook.ipynb"
        save_path = bpy.path.abspath(f"//{notebook_name}")

        # Get current .blend file name
        blend_file_name = bpy.path.basename(bpy.data.filepath)

        # Get frame range from the scene
        first_frame = context.scene.gcr_first_frame
        last_frame = context.scene.gcr_last_frame

        # Format the Blender version for URL
        version_url = f"Blender{blender_version}"  # For example, 4.1 -> Blender41

        # Content for the Jupyter Notebook with separate cells
        notebook_content = {
            "cells": [
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": [
                        "from google.colab import drive\n",
                        "drive.mount('/content/drive')\n"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": [
                        f"# Replace Blender version in URL and filename\n",
                        f"!wget https://download.blender.org/release/{version_url}/blender-{blender_version}.0-linux-x64.tar.xz\n"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": [
                        f"!tar xf blender-{blender_version}.0-linux-x64.tar.xz\n"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": [
                        f"# Replace .blend filename\n",
                        f"filename = \"/content/drive/MyDrive/{blend_file_name}\"\n"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": [
                        f"!./blender-{blender_version}-linux-x64/blender -b $filename -noaudio -E 'CYCLES' -o '/content/drive/MyDrive/Render' -a -s {first_frame} -e {last_frame} -F 'PNG' -- --cycles-device CUDA\n"
                    ]
                }
            ],
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3"
                },
                "language_info": {
                    "codemirror_mode": {
                        "name": "ipython",
                        "version": 3
                    },
                    "file_extension": ".py",
                    "mimetype": "text/x-python",
                    "name": "python",
                    "nbconvert_exporter": "python",
                    "pygments_lexer": "ipython3",
                    "version": "3.8.5"
                }
            },
            "nbformat": 4,
            "nbformat_minor": 5
        }

        try:
            with open(save_path, 'w') as file:
                json.dump(notebook_content, file, indent=4)
            self.report({'INFO'}, f".ipynb file saved to {save_path}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save .ipynb file: {str(e)}")
        
        return {'FINISHED'}

def register():
    # Register custom properties
    bpy.types.Scene.gcr_show_options = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.gcr_render_engine = bpy.props.EnumProperty(
        items=[
            ('BLENDER_EEVEE', "Eevee", ""),
            ('CYCLES', "Cycles", ""),
        ],
        name="Render Engine"
    )
    bpy.types.Scene.gcr_first_frame = bpy.props.IntProperty(name="First Frame", default=1)
    bpy.types.Scene.gcr_last_frame = bpy.props.IntProperty(name="Last Frame", default=250)
    
    # Blender version options
    bpy.types.Scene.gcr_blender_version = bpy.props.EnumProperty(
        items=get_blender_version_items(),
        name="Blender Version",
        description="Select Blender version"
    )

    bpy.utils.register_class(GCRAddonPanel)
    bpy.utils.register_class(SaveAndShowOptionsOperator)
    bpy.utils.register_class(SavePyFileOperator)

def unregister():
    # Unregister custom properties
    del bpy.types.Scene.gcr_show_options
    del bpy.types.Scene.gcr_render_engine
    del bpy.types.Scene.gcr_first_frame
    del bpy.types.Scene.gcr_last_frame
    del bpy.types.Scene.gcr_blender_version

    bpy.utils.unregister_class(GCRAddonPanel)
    bpy.utils.unregister_class(SaveAndShowOptionsOperator)
    bpy.utils.unregister_class(SavePyFileOperator)

if __name__ == "__main__":
    register()
